from django.apps import AppConfig


class RenaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rena'
