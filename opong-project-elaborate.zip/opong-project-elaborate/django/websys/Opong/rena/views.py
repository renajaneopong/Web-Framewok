
from django.shortcuts import render

from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic.base import TemplateView


def contactpage(request):
    template_name = "rena\\fpage.html"
    context = { 'info' :'(FUNCTION VIEWS)'}
    return render(request,template_name, context) 

class contactpg(TemplateView):
    
    template_name = "rena\cpage.html"
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['info'] =  '(CLASS VIEWS)'
        return context
    
