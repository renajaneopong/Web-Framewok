
from django.urls import path
from . import views 
from rena.views import contactpg
app_name = 'rena'

urlpatterns = [
    path('functionv',views.contactpage , name = 'contactpage'),
    path('classv',contactpg.as_view(), name = 'contactpg')

]